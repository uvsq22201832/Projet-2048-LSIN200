# Créé par ys000, le 20/02/2023 en Python 3.7

from casesup import *
from Fuz import *
from Mouvement import *
from time import *
from init import *
from gameset import *
from pynput import *
from pynput.keyboard import Key
from victory import *
from possible import *

#Bon du coups c'est pas des conditions, c'est le jeu
#Sans intérface graphique, tout apparaît dans la console

def start():
    global table
    table = ini()
    table = [[2, 4, 8, 16]
    ,[32, 4, 2, 4]
    ,[64, 2, 8, 4]
    ,[8, 8, 32, 4]]
    print("")
    print(table[0])
    print(table[1])
    print(table[2])
    print(table[3])
    print("")
    def inp(key):
        global table
        a = False
        win = False
        i = 0
        #while win == False and i < 15:
        poss = possibility(table)

        if  key == Key.right and 'R' in poss:
            table = game(table,'R')
            a = True

        elif key == Key.left and 'L' in poss:
            table = game(table,'L')
            a = True

        elif key == Key.up and 'U' in poss:
            table = game(table,'U')
            a = True

        elif key == Key.down and 'D' in poss:
            table = game(table,'D')
            a = True

            #Fonction win qui arrête tout en cas de victoire sinon break

        if a:
            table = casebonus(table)
            print("")
            print(table[0])
            print(table[1])
            print(table[2])
            print(table[3])
            print("")
            winlose(table)
            a = False



            #return table

    with keyboard.Listener(on_release=inp) as listener:
        listener.join()
start()



