# Créé par ys000, le 20/02/2023 en Python 3.7

from casesup import *
from Fuz import *
from Mouvement import *
from time import *
from init import *
from gameset import *
from pynput import *
from pynput.keyboard import Key
from victory import *
from possible import *


def start():
    global table
    table = ini()
    print("")
    print(table[0])
    print(table[1])
    print(table[2])
    print(table[3])
    print("")
    def inp(key):
        global table
        
        win = False
        i = 0
        #while win == False and i < 15:
        poss = possibility(table)
        if  key == Key.right and 'R' in poss:
            table = game(table,'R') 
            
        elif key == Key.left and 'L' in poss:
            table = game(table,'L')
            
        elif key == Key.up and 'U' in poss:
            table = game(table,'U')
            
        elif key == Key.down and 'D' in poss:
            table = game(table,'D')
            
            #Fonction win qui arrête tout en cas de victoire sinon break
            
            
            
    
        table = casebonus(table)
        print("")
        print(table[0])
        print(table[1])
        print(table[2])
        print(table[3])
        print("")
        winlose(table)
        
        
            #return table
            
    with keyboard.Listener(on_release=inp) as listener:
        listener.join()
start()



