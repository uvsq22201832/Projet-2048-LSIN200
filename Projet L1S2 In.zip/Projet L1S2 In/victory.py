def winlose(table):
    for i in range(len(table)):
                if 2048 in table[i]:
                    win = True
                    print("Victoire !")
                    break
                    #Programme de gêle du jeu + écran de victoire
                else:
                    a=0
                    b=0
                    for i in range(len(table)-1):
                        for j in range(len(table[0])-1):
                            if table[i][j]==table[i+1][j]:
                                a +=1
                            elif table[i][j]==table[i][j+1]:
                                b+=1
                    if a == 0 and b == 0:
                        print("lose")
                        break
                        #Programme de gêle du jeu + écran de défaite
                    else:
                        print("continue")
                        break
                        #Continue le jeu
"""
tabl = [[1,2,3,4],[5,6,7,8],[9,10,11,11],[13,14,15,16]]
winlose(tabl)
"""