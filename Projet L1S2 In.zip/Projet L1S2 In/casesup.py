# Créé par ys000, le 19/02/2023 en Python 3.7
from random import *

def casebonus(table):
    vide = []
    for i in range(len(table)):
        for j in range(len(table)):
            if table[i][j] == 0:
                vide.append([i,j])

    if vide:
        a = randint(0,len(vide)-1)
        b = randint(1,10)
        if b <= 9:
            table[vide[a][0]][vide[a][1]] = 2
        else:
            table[vide[a][0]][vide[a][1]] = 4

    return table


"""
#Les test
tabltest = [[4,2,2,0],[0,2,2,4],[2,0,0,4],[2,0,0,8]]


print(tabltest[0])
print(tabltest[1])
print(tabltest[2])
print(tabltest[3])
print("")

print(casebonus(tabltest))"""