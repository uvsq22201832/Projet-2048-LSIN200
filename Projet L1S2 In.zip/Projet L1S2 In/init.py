# Créé par ys000, le 20/02/2023 en Python 3.7
from casesup import *

def ini():
    table = [[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]]
    table = casebonus(table)
    table = casebonus(table)
    return table

